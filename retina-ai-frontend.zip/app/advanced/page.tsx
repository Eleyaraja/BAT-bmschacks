import { AppShell } from "@/components/layout/app-shell"
import { AdvancedFeatures } from "@/components/pages/advanced-features"

export default function Page() {
  return (
    <AppShell>
      <AdvancedFeatures />
    </AppShell>
  )
}
