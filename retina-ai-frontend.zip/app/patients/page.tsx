import { AppShell } from "@/components/layout/app-shell"
import { PatientManagement } from "@/components/pages/patient-management"

export default function Page() {
  return (
    <AppShell>
      <PatientManagement />
    </AppShell>
  )
}
