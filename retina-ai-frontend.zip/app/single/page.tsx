import { AppShell } from "@/components/layout/app-shell"
import { SingleAnalysis } from "@/components/pages/single-analysis"

export default function Page() {
  return (
    <AppShell>
      <SingleAnalysis />
    </AppShell>
  )
}
