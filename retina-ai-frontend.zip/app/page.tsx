import { AppShell } from "@/components/layout/app-shell"
import { DashboardOverview } from "@/components/pages/dashboard-overview"

export default function Page() {
  return (
    <AppShell>
      <DashboardOverview />
    </AppShell>
  )
}
