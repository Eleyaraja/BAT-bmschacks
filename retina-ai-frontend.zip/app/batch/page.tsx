import { AppShell } from "@/components/layout/app-shell"
import { BatchAnalysis } from "@/components/pages/batch-analysis"

export default function Page() {
  return (
    <AppShell>
      <BatchAnalysis />
    </AppShell>
  )
}
