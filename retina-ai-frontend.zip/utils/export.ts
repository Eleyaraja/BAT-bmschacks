import { jsPDF } from "jspdf"

export function exportCSV(rows: Record<string, any>[], filename: string) {
  if (!rows?.length) return
  const headers = Array.from(new Set(rows.flatMap((r) => Object.keys(r))))
  const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => JSON.stringify(r[h] ?? "")).join(","))].join(
    "\n",
  )
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

export function exportPDF(rows: Record<string, any>[], filename: string) {
  const doc = new jsPDF()
  doc.setFontSize(12)
  let y = 10
  rows.forEach((row, idx) => {
    doc.text(`Record ${idx + 1}:`, 10, y)
    y += 6
    Object.entries(row).forEach(([k, v]) => {
      doc.text(`${k}: ${String(v)}`, 10, y)
      y += 6
    })
    y += 4
    if (y > 280) {
      doc.addPage()
      y = 10
    }
  })
  doc.save(filename)
}
