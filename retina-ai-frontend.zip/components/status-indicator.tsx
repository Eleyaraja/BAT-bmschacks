"use client"

import useSWR from "swr"
import { useApiConfig } from "@/hooks/use-api-config"

export function StatusIndicator() {
  const { baseURL, fetcher } = useApiConfig()
  const { data, error, isLoading } = useSWR(baseURL ? `${baseURL}/health` : null, fetcher, {
    revalidateOnFocus: false,
    shouldRetryOnError: true,
  })

  const online = typeof navigator !== "undefined" ? navigator.onLine : true
  const apiUp = !!data && !error

  return (
    <div className="text-xs">
      <div aria-live="polite" className="flex items-center gap-2">
        <span className={`inline-block h-2 w-2 rounded-full ${online ? "bg-green-500" : "bg-destructive"}`} />
        <span>{online ? "Online" : "Offline"}</span>
      </div>
      <div className="flex items-center gap-2 mt-1">
        <span
          className={`inline-block h-2 w-2 rounded-full ${
            isLoading ? "bg-muted-foreground" : apiUp ? "bg-blue-500" : "bg-destructive"
          }`}
        />
        <span>{isLoading ? "Checking API..." : apiUp ? "Backend OK" : "Backend Unavailable"}</span>
      </div>
    </div>
  )
}
