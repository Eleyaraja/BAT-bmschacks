"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useApiConfig } from "@/hooks/use-api-config"

export function APITester() {
  const { baseURL, client } = useApiConfig()
  const [method, setMethod] = useState<"GET" | "POST" | "PUT" | "DELETE">("GET")
  const [path, setPath] = useState("/health")
  const [body, setBody] = useState("{}")
  const [resp, setResp] = useState<string>("")

  const send = async () => {
    if (!baseURL) return
    try {
      const url = `${baseURL}${path}`
      const data = method === "GET" || method === "DELETE" ? undefined : JSON.parse(body || "{}")
      const r = await client.request({ url, method, data })
      setResp(JSON.stringify(r.data, null, 2))
    } catch (e: any) {
      setResp(e?.message ?? "Request failed")
    }
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
        <select
          className="border border-border rounded-md px-2 py-1 bg-background"
          value={method}
          onChange={(e) => setMethod(e.target.value as any)}
        >
          <option>GET</option>
          <option>POST</option>
          <option>PUT</option>
          <option>DELETE</option>
        </select>
        <Input
          className="md:col-span-3"
          value={path}
          onChange={(e) => setPath(e.target.value)}
          placeholder="/endpoint"
        />
      </div>
      <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={6} placeholder='{"key":"value"}' />
      <Button onClick={send}>Send</Button>
      <pre className="mt-2 p-3 rounded-md bg-muted text-xs overflow-auto">{resp || "Response will appear here."}</pre>
    </div>
  )
}
