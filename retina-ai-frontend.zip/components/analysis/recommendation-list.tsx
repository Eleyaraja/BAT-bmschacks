"use client"

export function RecommendationList({ items }: { items: string[] }) {
  if (!items?.length) return null
  return (
    <ul className="list-disc ml-6 space-y-1 text-sm">
      {items.map((it, idx) => (
        <li key={idx}>{it}</li>
      ))}
    </ul>
  )
}
