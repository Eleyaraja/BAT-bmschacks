"use client"

export function RiskIndicator({ risk }: { risk: number }) {
  const pct = Math.max(0, Math.min(1, risk))
  const color = pct < 0.33 ? "bg-green-500" : pct < 0.66 ? "bg-yellow-500" : "bg-destructive"
  return (
    <div>
      <div className="text-xs mb-1 text-muted-foreground">Risk</div>
      <div className="h-2 w-full rounded bg-muted overflow-hidden">
        <div className={`h-full ${color}`} style={{ width: `${pct * 100}%` }} />
      </div>
    </div>
  )
}
