"use client"

import { Button } from "@/components/ui/button"
import { exportCSV, exportPDF } from "@/utils/export"

export function ExportPanel({
  rows,
  filenameBase = "analysis",
}: { rows: Record<string, any>[]; filenameBase?: string }) {
  return (
    <div className="flex items-center gap-2">
      <Button size="sm" variant="outline" onClick={() => exportCSV(rows, `${filenameBase}.csv`)}>
        Export CSV
      </Button>
      <Button size="sm" onClick={() => exportPDF(rows, `${filenameBase}.pdf`)}>
        Export PDF
      </Button>
    </div>
  )
}
