"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function ResultsCard({
  result,
}: { result: { primary: string; risk: "low" | "moderate" | "high"; summary?: string } }) {
  const riskColor = {
    low: "text-green-600",
    moderate: "text-yellow-600",
    high: "text-destructive",
  }[result.risk]
  return (
    <Card>
      <CardHeader>
        <CardTitle>Analysis Result</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="text-sm">
          Primary Condition: <span className="font-medium">{result.primary}</span>
        </div>
        <div className={`text-sm font-medium ${riskColor}`}>Risk Level: {result.risk.toUpperCase()}</div>
        {result.summary ? <p className="text-sm text-muted-foreground">{result.summary}</p> : null}
      </CardContent>
    </Card>
  )
}
