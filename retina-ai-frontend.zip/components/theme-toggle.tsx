"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"

export function ThemeToggle() {
  const [dark, setDark] = useState(false)
  useEffect(() => {
    const root = document.documentElement
    if (dark) root.classList.add("dark")
    else root.classList.remove("dark")
  }, [dark])

  return (
    <Button variant="outline" size="sm" aria-pressed={dark} onClick={() => setDark((v) => !v)}>
      {dark ? "Light" : "Dark"}
    </Button>
  )
}
