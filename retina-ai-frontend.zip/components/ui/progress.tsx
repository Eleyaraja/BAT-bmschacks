"use client"

export function Progress({ value = 0 }: { value?: number }) {
  return (
    <div className="h-2 w-full rounded bg-muted">
      <div
        className="h-full rounded bg-primary transition-all"
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  )
}
