"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ProgressTimeline } from "@/components/visualizations/progress-timeline"

export function PatientManagement() {
  const [patient, setPatient] = useState({ id: "", name: "", dob: "" })

  const timeline = [
    { date: "2024-01", score: 0.42 },
    { date: "2024-06", score: 0.55 },
    { date: "2025-01", score: 0.63 },
  ]

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Patient Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input
            placeholder="Patient ID"
            value={patient.id}
            onChange={(e) => setPatient((p) => ({ ...p, id: e.target.value }))}
          />
          <Input
            placeholder="Full Name"
            value={patient.name}
            onChange={(e) => setPatient((p) => ({ ...p, name: e.target.value }))}
          />
          <Input
            placeholder="Date of Birth"
            value={patient.dob}
            onChange={(e) => setPatient((p) => ({ ...p, dob: e.target.value }))}
          />
          <Button size="sm">Save</Button>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Progress Tracking</CardTitle>
        </CardHeader>
        <CardContent>
          <ProgressTimeline data={timeline} />
        </CardContent>
      </Card>
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Comparative Analysis</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          Side-by-side comparison and historical progression visualization will display here.
        </CardContent>
      </Card>
    </div>
  )
}
