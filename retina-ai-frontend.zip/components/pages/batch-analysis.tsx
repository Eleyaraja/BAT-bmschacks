"use client"

import { useState } from "react"
import { DragDropZone } from "@/components/upload/drag-drop-zone"
import { BatchUploadQueue } from "@/components/upload/batch-upload-queue"
import { ExportPanel } from "@/components/analysis/export-panel"

export function BatchAnalysis() {
  const [results, setResults] = useState<Record<string, any>[]>([])

  // TODO: integrate batch progress via WebSocket and backend job IDs
  const rows = results.length
    ? results
    : [
        { file: "retina_001.jpg", primary: "DR", risk: "moderate", dr: 0.72, amd: 0.18, glaucoma: 0.1 },
        { file: "retina_002.jpg", primary: "AMD", risk: "high", dr: 0.1, amd: 0.82, glaucoma: 0.08 },
      ]

  return (
    <div className="space-y-6">
      <DragDropZone
        multiple
        onFilesAccepted={(files) => {
          // Hook into BatchUploadQueue or your backend upload
          console.log(
            "[v0] Added to batch:",
            files.map((f) => f.name),
          )
        }}
      />
      <BatchUploadQueue />
      <div className="overflow-auto border border-border rounded-md">
        <table className="w-full text-sm">
          <thead className="bg-muted">
            <tr>
              <th className="text-left p-2">File</th>
              <th className="text-left p-2">Primary</th>
              <th className="text-left p-2">Risk</th>
              <th className="text-right p-2">DR</th>
              <th className="text-right p-2">AMD</th>
              <th className="text-right p-2">Glaucoma</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-t border-border">
                <td className="p-2">{r.file}</td>
                <td className="p-2">{r.primary}</td>
                <td className="p-2 capitalize">{r.risk}</td>
                <td className="p-2 text-right">{Math.round((r.dr ?? 0) * 100)}%</td>
                <td className="p-2 text-right">{Math.round((r.amd ?? 0) * 100)}%</td>
                <td className="p-2 text-right">{Math.round((r.glaucoma ?? 0) * 100)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ExportPanel rows={rows} filenameBase="batch-results" />
    </div>
  )
}
