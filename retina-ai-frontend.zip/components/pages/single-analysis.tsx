"use client"

import { useMemo, useState } from "react"
import { DragDropZone } from "@/components/upload/drag-drop-zone"
import { ImagePreview } from "@/components/upload/image-preview"
import { Button } from "@/components/ui/button"
import { ResultsCard } from "@/components/analysis/results-card"
import { ConfidenceChart } from "@/components/visualizations/confidence-chart"
import { RiskIndicator } from "@/components/analysis/risk-indicator"
import { RecommendationList } from "@/components/analysis/recommendation-list"
import { ExportPanel } from "@/components/analysis/export-panel"
import { useApiConfig } from "@/hooks/use-api-config"
import useSWRMutation from "swr/mutation"

export function SingleAnalysis() {
  const [file, setFile] = useState<File | null>(null)
  const [autoEnhance, setAutoEnhance] = useState(true)
  const { baseURL, client } = useApiConfig()

  const { trigger, isMutating, data } = useSWRMutation(
    baseURL ? `${baseURL}/analyze` : null,
    async (url: string, { arg }: { arg: FormData }) => {
      const res = await client.post(url, arg, { headers: { "Content-Type": "multipart/form-data" } })
      return res.data
    },
  )

  const handleAnalyze = async () => {
    if (!file || !baseURL) return
    const fd = new FormData()
    fd.append("image", file)
    fd.append("autoEnhance", String(autoEnhance))
    await trigger(fd)
  }

  const confData = useMemo(() => {
    const probs = data?.probabilities ?? { DR: 0.7, AMD: 0.2, Glaucoma: 0.1 }
    return Object.entries(probs).map(([label, value]) => ({ label, value: Number(value) }))
  }, [data])

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <div className="space-y-4">
        <DragDropZone onFilesAccepted={(files) => setFile(files[0])} />
        <ImagePreview file={file} autoEnhance={autoEnhance} onToggleEnhance={setAutoEnhance} />
        <div className="flex gap-2">
          <Button onClick={handleAnalyze} disabled={!file || isMutating}>
            {isMutating ? "Analyzing..." : "Analyze"}
          </Button>
          <Button variant="outline" onClick={() => setFile(null)} disabled={!file}>
            Clear
          </Button>
        </div>
      </div>
      <div className="space-y-4">
        <ResultsCard result={{ primary: data?.primary ?? "Diabetic Retinopathy", risk: data?.risk ?? "moderate" }} />
        <RiskIndicator risk={data?.riskScore ?? 0.55} />
        <ConfidenceChart data={confData} />
        <RecommendationList
          items={data?.recommendations ?? ["Schedule follow-up in 3 months", "Monitor glucose levels"]}
        />
        <ExportPanel rows={[data ?? {}]} filenameBase="single-analysis" />
      </div>
    </div>
  )
}
