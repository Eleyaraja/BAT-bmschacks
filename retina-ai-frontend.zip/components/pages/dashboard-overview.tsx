"use client"

import useSWR from "swr"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useApiConfig } from "@/hooks/use-api-config"
import { ConfidenceChart } from "@/components/visualizations/confidence-chart"

export function DashboardOverview() {
  const { baseURL, fetcher } = useApiConfig()
  const { data } = useSWR(baseURL ? `${baseURL}/stats/recent` : null, fetcher, { revalidateOnFocus: false })

  const chartData = (data?.modelPerformance ?? [
    { label: "DR", value: 0.92 },
    { label: "AMD", value: 0.88 },
    { label: "Glaucoma", value: 0.85 },
  ]) as { label: string; value: number }[]

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Real-time System Status</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Queue: {data?.queue ?? 0} • Uptime: {data?.uptime ?? "—"}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="flex gap-2">
          <Link href="/single">
            <Button size="sm">New Analysis</Button>
          </Link>
          <Link href="/batch">
            <Button size="sm" variant="secondary">
              Batch
            </Button>
          </Link>
        </CardContent>
      </Card>

      <Card className="lg:col-span-3">
        <CardHeader>
          <CardTitle>Model Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <ConfidenceChart data={chartData} />
        </CardContent>
      </Card>
    </div>
  )
}
