"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { APITester } from "@/components/tools/api-tester"

export function AdvancedFeatures() {
  const [threshold, setThreshold] = useState(0.5)
  const [settings, setSettings] = useState({ denoise: 0, sharpen: 0, contrast: 0 })

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Enhancement Toolbox</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <ToolRow
            label="Denoise"
            value={settings.denoise}
            onChange={(v) => setSettings((s) => ({ ...s, denoise: v }))}
          />
          <ToolRow
            label="Sharpen"
            value={settings.sharpen}
            onChange={(v) => setSettings((s) => ({ ...s, sharpen: v }))}
          />
          <ToolRow
            label="Contrast"
            value={settings.contrast}
            onChange={(v) => setSettings((s) => ({ ...s, contrast: v }))}
          />
          <Button size="sm" variant="secondary">
            Preview
          </Button>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Confidence Threshold</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-sm">Threshold: {Math.round(threshold * 100)}%</div>
          <Slider value={[threshold]} min={0} max={1} step={0.01} onValueChange={(v) => setThreshold(v[0])} />
        </CardContent>
      </Card>
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Model Insights</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          Grad-CAM heatmaps, feature importance, and calibration charts can be shown here.
        </CardContent>
      </Card>
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>API Testing</CardTitle>
        </CardHeader>
        <CardContent>
          <APITester />
        </CardContent>
      </Card>
    </div>
  )
}

function ToolRow({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <div className="flex items-center justify-between">
        <span className="text-sm">{label}</span>
        <span className="text-xs text-muted-foreground">{Math.round(value * 100)}%</span>
      </div>
      <Slider value={[value]} min={0} max={1} step={0.01} onValueChange={(v) => onChange(v[0])} />
    </div>
  )
}
