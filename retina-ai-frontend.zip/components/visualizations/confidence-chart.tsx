"use client"

import { Bar, BarChart, CartesianGrid, LabelList, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

export type ConfidenceDatum = { label: string; value: number }

export function ConfidenceChart({ data }: { data: ConfidenceDatum[] }) {
  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid vertical={false} stroke="var(--color-border)" />
          <XAxis dataKey="label" tickLine={false} axisLine={false} />
          <YAxis tickFormatter={(v) => `${Math.round(v * 100)}%`} tickLine={false} axisLine={false} />
          <Tooltip formatter={(v: number) => `${Math.round(v * 100)}%`} />
          <Bar dataKey="value" fill="var(--color-chart-2)" radius={4}>
            <LabelList dataKey="value" position="top" formatter={(v: number) => `${Math.round(v * 100)}%`} />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
