"use client"

import { useEffect, useRef } from "react"

type Props = {
  imageUrl: string
  heatmap?: number[][] // normalized [0..1]
}

export function HeatmapOverlay({ imageUrl, heatmap }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")!
    const img = new Image()
    img.crossOrigin = "anonymous"
    img.onload = () => {
      canvas.width = img.width
      canvas.height = img.height
      ctx.drawImage(img, 0, 0)
      if (!heatmap) return
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height)
      const data = imgData.data
      // Simple red overlay based on heatmap alpha
      for (let y = 0; y < canvas.height; y++) {
        for (let x = 0; x < canvas.width; x++) {
          const idx = (y * canvas.width + x) * 4
          const a =
            heatmap?.[Math.floor((y / canvas.height) * heatmap.length)]?.[
              Math.floor((x / canvas.width) * heatmap[0].length)
            ] ?? 0
          // blend red onto pixel
          data[idx] = Math.min(255, data[idx] * (1 - a) + 255 * a)
          data[idx + 1] = data[idx + 1] * (1 - a)
          data[idx + 2] = data[idx + 2] * (1 - a)
        }
      }
      ctx.putImageData(imgData, 0, 0)
    }
    img.src = imageUrl
  }, [imageUrl, heatmap])

  return (
    <canvas ref={canvasRef} className="w-full h-auto rounded-md border border-border" aria-label="Heatmap overlay" />
  )
}
