"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { StatusIndicator } from "@/components/status-indicator"
import { ThemeToggle } from "@/components/theme-toggle"
import { cn } from "@/lib/utils"

const nav = [
  { href: "/", label: "Dashboard" },
  { href: "/single", label: "Single Analysis" },
  { href: "/batch", label: "Batch Analysis" },
  { href: "/patients", label: "Patients" },
  { href: "/advanced", label: "Advanced" },
]

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  return (
    <div className="min-h-screen bg-background text-foreground flex">
      <aside className="hidden md:flex w-64 flex-col border-r border-border bg-(--color-sidebar)">
        <div className="p-4">
          <Link href="/" className="font-semibold">
            Retina AI
          </Link>
        </div>
        <nav className="flex-1 p-2">
          <ul className="flex flex-col gap-2">
            {nav.map((n) => (
              <li key={n.href}>
                <Link
                  href={n.href}
                  className={cn(
                    "block rounded-md px-3 py-2 text-sm",
                    pathname === n.href
                      ? "bg-(--color-sidebar-accent) text-(--color-sidebar-accent-foreground)"
                      : "hover:bg-(--color-sidebar-accent) hover:text-(--color-sidebar-accent-foreground)",
                  )}
                >
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <div className="p-4 border-t border-(--color-sidebar-border)">
          <StatusIndicator />
        </div>
      </aside>
      <main className="flex-1 flex flex-col">
        <header className="border-b border-border bg-card">
          <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="md:hidden">
                <StatusIndicator />
              </div>
              <span className="font-medium">Retinal Disease Classification</span>
            </div>
            <div className="flex items-center gap-2">
              <Link href="/advanced">
                <Button size="sm" variant="secondary">
                  API Tester
                </Button>
              </Link>
              <ThemeToggle />
            </div>
          </div>
        </header>
        <div className="mx-auto w-full max-w-7xl p-4">{children}</div>
      </main>
    </div>
  )
}
