"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"

type Props = {
  file: File | null
  autoEnhance: boolean
  onToggleEnhance: (v: boolean) => void
}

export function ImagePreview({ file, autoEnhance, onToggleEnhance }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [scale, setScale] = useState(1)
  const [pos, setPos] = useState({ x: 0, y: 0 })
  const [drag, setDrag] = useState<{ x: number; y: number } | null>(null)

  useEffect(() => {
    if (!file || !canvasRef.current) return
    const url = URL.createObjectURL(file)
    const img = new Image()
    img.crossOrigin = "anonymous" // CORS-safe per guidance
    img.onload = () => {
      const ctx = canvasRef.current!.getContext("2d")!
      const { width, height } = canvasRef.current!
      ctx.clearRect(0, 0, width, height)
      const w = img.width * scale
      const h = img.height * scale
      // Simple auto-enhance stub (increase contrast slightly)
      ctx.filter = autoEnhance ? "contrast(1.1) saturate(1.05)" : "none"
      ctx.drawImage(img, pos.x, pos.y, w, h)
      URL.revokeObjectURL(url)
    }
    img.src = url
  }, [file, scale, pos, autoEnhance])

  return (
    <div className="w-full">
      <div className="flex items-center gap-2 mb-2">
        <Button size="sm" variant="outline" onClick={() => setScale((s) => Math.min(s + 0.1, 4))}>
          Zoom In
        </Button>
        <Button size="sm" variant="outline" onClick={() => setScale((s) => Math.max(s - 0.1, 0.2))}>
          Zoom Out
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            setScale(1)
            setPos({ x: 0, y: 0 })
          }}
        >
          Reset
        </Button>
        <Button size="sm" variant={autoEnhance ? "default" : "outline"} onClick={() => onToggleEnhance(!autoEnhance)}>
          {autoEnhance ? "Auto-Enhance: On" : "Auto-Enhance: Off"}
        </Button>
      </div>
      <div
        className="relative border border-border rounded-lg bg-card"
        onMouseDown={(e) => setDrag({ x: e.clientX - pos.x, y: e.clientY - pos.y })}
        onMouseMove={(e) => {
          if (!drag) return
          setPos({ x: e.clientX - drag.x, y: e.clientY - drag.y })
        }}
        onMouseUp={() => setDrag(null)}
        onMouseLeave={() => setDrag(null)}
      >
        <canvas
          ref={canvasRef}
          width={800}
          height={500}
          aria-label="Image Preview"
          className="w-full h-auto rounded-lg"
        />
      </div>
    </div>
  )
}
