"use client"

import type React from "react"

import { useCallback, useRef, useState } from "react"
import { cn } from "@/lib/utils"

type Props = {
  onFilesAccepted: (files: File[]) => void
  multiple?: boolean
  accept?: string[]
  maxSizeMB?: number
}

export function DragDropZone({
  onFilesAccepted,
  multiple = false,
  accept = ["image/jpeg", "image/png", "image/tiff"],
  maxSizeMB = 20,
}: Props) {
  const [dragOver, setDragOver] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const validate = (files: File[]) => {
    const valid: File[] = []
    for (const f of files) {
      if (f.size > maxSizeMB * 1024 * 1024) continue
      if (!accept.includes(f.type)) continue
      valid.push(f)
    }
    return valid
  }

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setDragOver(false)
      const files = Array.from(e.dataTransfer.files)
      const valid = validate(files)
      if (valid.length) onFilesAccepted(multiple ? valid : [valid[0]])
    },
    [multiple, onFilesAccepted],
  )

  const onChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files ? Array.from(e.target.files) : []
      const valid = validate(files)
      if (valid.length) onFilesAccepted(multiple ? valid : [valid[0]])
    },
    [multiple, onFilesAccepted],
  )

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label="Upload images"
      onClick={() => inputRef.current?.click()}
      onKeyDown={(e) => {
        if (e.key === "Enter") inputRef.current?.click()
      }}
      onDragOver={(e) => {
        e.preventDefault()
        setDragOver(true)
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={onDrop}
      className={cn(
        "w-full rounded-lg border-2 border-dashed p-6 text-center cursor-pointer",
        dragOver ? "border-primary bg-accent" : "border-border bg-card",
      )}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept.join(",")}
        multiple={multiple}
        className="hidden"
        onChange={onChange}
      />
      <p className="text-sm text-muted-foreground">Drag & drop images here, or click to browse</p>
      <p className="text-xs text-muted-foreground mt-1">Accepted: JPG, PNG, TIFF • Max {maxSizeMB}MB</p>
    </div>
  )
}
