"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

export type BatchItem = {
  id: string
  file: File
  progress: number
  status: "queued" | "uploading" | "processing" | "done" | "error"
  resultUrl?: string
}

export function BatchUploadQueue() {
  const [items, setItems] = useState<BatchItem[]>([])

  const addFiles = (files: File[]) => {
    setItems((prev) => [
      ...prev,
      ...files.map((f, idx) => ({
        id: `${Date.now()}-${idx}`,
        file: f,
        progress: 0,
        status: "queued" as const,
      })),
    ])
  }

  const start = async () => {
    for (const it of items) {
      setItems((prev) => prev.map((p) => (p.id === it.id ? { ...p, status: "uploading", progress: 10 } : p)))
      // TODO: integrate with Flask upload endpoint
      await new Promise((r) => setTimeout(r, 300))
      setItems((prev) => prev.map((p) => (p.id === it.id ? { ...p, status: "processing", progress: 60 } : p)))
      await new Promise((r) => setTimeout(r, 500))
      setItems((prev) =>
        prev.map((p) => (p.id === it.id ? { ...p, status: "done", progress: 100, resultUrl: "#" } : p)),
      )
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Button size="sm" variant="secondary" onClick={() => document.getElementById("batch-hidden-input")?.click()}>
          Add Files
        </Button>
        <input
          id="batch-hidden-input"
          type="file"
          accept="image/*"
          className="hidden"
          multiple
          onChange={(e) => {
            const files = e.target.files ? Array.from(e.target.files) : []
            if (files.length) addFiles(files)
          }}
        />
        <Button size="sm" onClick={start}>
          Start Processing
        </Button>
      </div>
      <ul className="space-y-2">
        {items.map((it) => (
          <li key={it.id} className="border border-border rounded-md p-3">
            <div className="text-sm">{it.file.name}</div>
            <div className="text-xs text-muted-foreground mb-1 capitalize">{it.status}</div>
            <Progress value={it.progress} />
          </li>
        ))}
      </ul>
    </div>
  )
}
