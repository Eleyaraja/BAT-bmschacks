"use client"

import axios from "axios"

export function useApiConfig() {
  const baseURL = process.env.NEXT_PUBLIC_API_BASE_URL || ""
  const client = axios.create({ baseURL, timeout: 30000 })
  const fetcher = (url: string) => client.get(url).then((r) => r.data)
  return { baseURL, client, fetcher }
}
