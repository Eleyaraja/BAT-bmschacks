"use client"

import { useEffect, useRef, useState } from "react"

export function useWebSocket(url?: string) {
  const wsRef = useRef<WebSocket | null>(null)
  const [messages, setMessages] = useState<any[]>([])
  const [ready, setReady] = useState(false)

  useEffect(() => {
    if (!url) return
    const ws = new WebSocket(url)
    wsRef.current = ws
    ws.onopen = () => setReady(true)
    ws.onmessage = (e) => setMessages((m) => [...m, JSON.parse(e.data)])
    ws.onerror = () => setReady(false)
    ws.onclose = () => setReady(false)
    return () => ws.close()
  }, [url])

  const send = (payload: any) => wsRef.current?.send(JSON.stringify(payload))
  return { ready, messages, send }
}
